package com.springcore;

public class Student 
{
	private int stuid;
	private String stuName;
	private String stuAddress;
	
	public Student(int stuid, String stuName, String stuAddress) {
		super();
		this.stuid = stuid;
		this.stuName = stuName;
		this.stuAddress = stuAddress;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getStuid() {
		return stuid;
	}

	public void setStuid(int stuid) {
		this.stuid = stuid;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuAddress() {
		return stuAddress;
	}

	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}

	@Override
	public String toString() {
		return "Student [stuid=" + stuid + ", stuName=" + stuName + ", stuAddress=" + stuAddress + "]";
	}
	
	
	
	
	

}
